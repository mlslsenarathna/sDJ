# contacts_contacts_inner_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**input** | **char \*** | Sent value | [optional] 
**status** | **char \*** | Contacts status:   *failed* - got error on processing  *processing* - still not detected  *invalid* - unavailable for sending  *valid* - available for sending | [optional] 
**wa_id** | **char \*** | Formatted contact phone | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


