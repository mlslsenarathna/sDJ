# send_message_status_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sent** | **int** |  | [optional] 
**id** | **char \*** | unique message id | [optional] 
**message** | **char \*** | Posting status message | [optional] 
**description** | **char \*** | Result description | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


