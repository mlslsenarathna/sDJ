# send_product_request_all_of_action_sections_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **char \*** | Title of the section. Example: the-section-title | [optional] 
**product_items** | [**list_t**](send_product_request_all_of_action_product_items.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


