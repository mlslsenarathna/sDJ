# channel_statistics_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | **char \*** |  | [optional] 
**templates_cost** | **double** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


