# channel_status_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **one_msg_waba_sdk_channel_status_STATUS_e** | channel Status | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


