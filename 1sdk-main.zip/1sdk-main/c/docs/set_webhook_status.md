# set_webhook_status_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**set** | **int** | Flag indicating that the current request has changed webhook | [optional] 
**message** | **char \*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


