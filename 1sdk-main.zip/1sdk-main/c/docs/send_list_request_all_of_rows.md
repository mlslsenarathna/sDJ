# send_list_request_all_of_rows_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **char \*** | Unique id for option, up to 200 symbols | 
**title** | **char \*** | Title of option, up to 24 symbols. | 
**description** | **char \*** | Description of option, up to 72 symbols | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


