# send_list_request_all_of_sections_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **char \*** | Title of section, up to 24 symbols. Required if there are more then 1 section | [optional] 
**rows** | [**list_t**](send_list_request_all_of_rows.md) \* |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


