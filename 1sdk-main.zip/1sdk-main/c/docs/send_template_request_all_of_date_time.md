# send_template_request_all_of_date_time_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**component** | [**send_template_request_all_of_date_time_component_t**](send_template_request_all_of_date_time_component.md) \* |  | [optional] 
**unix_epoch** | [**send_template_request_all_of_date_time_unix_epoch_t**](send_template_request_all_of_date_time_unix_epoch.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


