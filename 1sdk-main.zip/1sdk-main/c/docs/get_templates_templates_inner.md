# get_templates_templates_inner_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**category** | **template_category_prop_t \*** |  | [optional] 
**components** | **template_components_prop_t \*** |  | [optional] 
**language** | **template_language_prop_t \*** |  | [optional] 
**name** | **char \*** |  | [optional] 
**_namespace** | **char \*** | Can be found by method /templates | [optional] 
**rejected_reason** | **char \*** |  | [optional] 
**status** | **char \*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


