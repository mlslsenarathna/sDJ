# message_id_prop_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message_id** | **char \*** | Message ID. Example: 0XzkmGNn4prUAQlzsHApGNRXQ0U | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


