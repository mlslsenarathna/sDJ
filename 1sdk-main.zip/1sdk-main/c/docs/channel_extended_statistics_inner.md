# channel_extended_statistics_inner_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**business_initiated_paid_quantity** | **int** |  | [optional] 
**business_initiated_price** | **double** |  | [optional] 
**business_initiated_quantity** | **int** |  | [optional] 
**free_entry_point** | **int** |  | [optional] 
**free_quantity** | **int** |  | [optional] 
**free_tier** | **int** |  | [optional] 
**paid_quantity** | **int** |  | [optional] 
**period_date** | **char \*** |  | [optional] 
**quantity** | **double** |  | [optional] 
**total_price** | **double** |  | [optional] 
**user_initiated_paid_quantity** | **int** |  | [optional] 
**user_initiated_price** | **double** |  | [optional] 
**user_initiated_quantity** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


