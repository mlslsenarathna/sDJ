# send_template_request_all_of_params_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_default** | **char \*** |  | [optional] 
**currency** | [**send_template_request_all_of_currency_t**](send_template_request_all_of_currency.md) \* |  | [optional] 
**date_time** | [**send_template_request_all_of_date_time_t**](send_template_request_all_of_date_time.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


