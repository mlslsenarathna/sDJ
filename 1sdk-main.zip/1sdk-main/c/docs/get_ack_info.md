# get_ack_info_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hooks** | [**list_t**](get_ack_info_hooks_inner.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


