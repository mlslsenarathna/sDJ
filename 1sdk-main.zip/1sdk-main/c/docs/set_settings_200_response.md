# set_settings_200_response_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**webhook_url** | **char \*** |  | [optional] 
**update** | [**set_settings_200_response_all_of_update_t**](set_settings_200_response_all_of_update.md) \* |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


