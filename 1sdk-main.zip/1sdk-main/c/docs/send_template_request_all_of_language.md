# send_template_request_all_of_language_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**policy** | **one_msg_waba_sdk_send_template_request_all_of_language_POLICY_e** |  | [optional] 
**code** | **template_language_prop_t \*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


