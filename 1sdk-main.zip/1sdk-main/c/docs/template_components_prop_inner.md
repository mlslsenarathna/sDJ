# template_components_prop_inner_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **one_msg_waba_sdk_template_components_prop_inner_TYPE_e** |  | [optional] 
**format** | **one_msg_waba_sdk_template_components_prop_inner_FORMAT_e** | Only for HEADER type | [optional] 
**text** | **char \*** |  | [optional] 
**example** | [**object_t**](.md) \* |  | [optional] 
**buttons** | [**list_t**](template_components_prop_inner_buttons_inner.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


