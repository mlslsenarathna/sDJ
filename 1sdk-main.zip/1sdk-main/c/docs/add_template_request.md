# add_template_request_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **char \*** | Name of template | [optional] 
**category** | **template_category_prop_t \*** |  | [optional] 
**components** | **template_components_prop_t \*** |  | [optional] 
**language** | **template_language_prop_t \*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


