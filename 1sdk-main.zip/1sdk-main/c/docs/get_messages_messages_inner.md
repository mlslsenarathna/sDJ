# get_messages_messages_inner_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message_number** | **int** |  | [optional] 
**id** | **char \*** |  | [optional] 
**body** | **char \*** |  | [optional] 
**from_me** | **int** |  | [optional] 
**self** | **int** |  | [optional] 
**is_forwarded** | **int** |  | [optional] 
**author** | **char \*** |  | [optional] 
**time** | **int** |  | [optional] 
**chat_id** | **char \*** |  | [optional] 
**type** | **char \*** |  | [optional] 
**sender_name** | **char \*** |  | [optional] 
**caption** | **char \*** |  | [optional] 
**quoted_msg_id** | **char \*** |  | [optional] 
**metadata** | [**object_t**](.md) \* |  | [optional] 
**chat_name** | **char \*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


