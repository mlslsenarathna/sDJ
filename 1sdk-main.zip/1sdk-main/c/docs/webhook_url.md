# webhook_url_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**webhook_url** | **char \*** | Http or https URL for receiving notifications. For testing, we recommend using [our RequestBin](http://bin.1msg.io). | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


