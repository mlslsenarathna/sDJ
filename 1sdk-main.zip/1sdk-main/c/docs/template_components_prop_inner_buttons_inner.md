# template_components_prop_inner_buttons_inner_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **one_msg_waba_sdk_template_components_prop_inner_buttons_inner_TYPE_e** |  | [optional] 
**text** | **char \*** |  | [optional] 
**url** | **char \*** |  | [optional] 
**phone_number** | **char \*** |  | [optional] 
**example** | [**list_t**](any_type.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


