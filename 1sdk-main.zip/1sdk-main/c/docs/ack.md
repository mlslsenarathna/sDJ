# ack_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **char \*** | unique id of message | [optional] 
**chat_id** | **char \*** | chat ID | [optional] 
**status** | **one_msg_waba_sdk_ack_STATUS_e** | type of the message status | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


