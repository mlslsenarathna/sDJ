# get_ack_info_hooks_inner_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **char \*** |  | [optional] 
**type** | **char \*** |  | [optional] 
**status** | **char \*** |  | [optional] 
**pricing** | [**object_t**](.md) \* |  | [optional] 
**timestamp** | **char \*** |  | [optional] 
**conversation** | [**object_t**](.md) \* |  | [optional] 
**recipient_id** | **char \*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


