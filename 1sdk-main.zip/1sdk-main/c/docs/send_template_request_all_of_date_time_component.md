# send_template_request_all_of_date_time_component_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**day_of_week** | **one_msg_waba_sdk_send_template_request_all_of_date_time_component_DAYOFWEEK_e** |  | [optional] 
**year** | **int** |  | [optional] 
**month** | **int** |  | [optional] 
**day_of_month** | **int** |  | [optional] 
**hour** | **int** |  | [optional] 
**minute** | **int** |  | [optional] 
**calendar** | **one_msg_waba_sdk_send_template_request_all_of_date_time_component_CALENDAR_e** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


