# OneMessage.io.Model.SendMessageStatus

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Sent** | **bool** |  | [optional] 
**Id** | **string** | unique message id | [optional] 
**Message** | **string** | Posting status message | [optional] 
**Description** | **string** | Result description | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

