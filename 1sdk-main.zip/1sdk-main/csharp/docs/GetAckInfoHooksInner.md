# OneMessage.io.Model.GetAckInfoHooksInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [optional] 
**Type** | **string** |  | [optional] 
**Status** | **string** |  | [optional] 
**Pricing** | **Object** |  | [optional] 
**Timestamp** | **string** |  | [optional] 
**Conversation** | **Object** |  | [optional] 
**RecipientId** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

