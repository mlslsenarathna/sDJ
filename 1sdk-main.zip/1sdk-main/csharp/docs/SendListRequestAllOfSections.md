# OneMessage.io.Model.SendListRequestAllOfSections

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Title** | **string** | Title of section, up to 24 symbols. Required if there are more then 1 section | [optional] 
**Rows** | [**List&lt;SendListRequestAllOfRows&gt;**](SendListRequestAllOfRows.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

