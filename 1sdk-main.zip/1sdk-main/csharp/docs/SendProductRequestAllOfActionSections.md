# OneMessage.io.Model.SendProductRequestAllOfActionSections

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Title** | **string** | Title of the section. Example: the-section-title | [optional] 
**ProductItems** | [**List&lt;SendProductRequestAllOfActionProductItems&gt;**](SendProductRequestAllOfActionProductItems.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

