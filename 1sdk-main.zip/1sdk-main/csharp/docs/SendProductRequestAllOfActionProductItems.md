# OneMessage.io.Model.SendProductRequestAllOfActionProductItems

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ProductRetailerId** | **string** | id of the product | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

