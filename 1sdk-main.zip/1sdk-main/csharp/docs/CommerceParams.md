# OneMessage.io.Model.CommerceParams

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IsCartEnabled** | **bool** |  | 
**IsCatalogVisible** | **bool** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

