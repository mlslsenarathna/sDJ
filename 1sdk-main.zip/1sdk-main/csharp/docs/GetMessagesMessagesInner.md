# OneMessage.io.Model.GetMessagesMessagesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MessageNumber** | **int** |  | [optional] 
**Id** | **string** |  | [optional] 
**Body** | **string** |  | [optional] 
**FromMe** | **bool** |  | [optional] 
**Self** | **int** |  | [optional] 
**IsForwarded** | **int** |  | [optional] 
**Author** | **string** |  | [optional] 
**Time** | **int** |  | [optional] 
**ChatId** | **string** |  | [optional] 
**Type** | **string** |  | [optional] 
**SenderName** | **string** |  | [optional] 
**Caption** | **string** |  | [optional] 
**QuotedMsgId** | **string** |  | [optional] 
**Metadata** | **Object** |  | [optional] 
**ChatName** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

