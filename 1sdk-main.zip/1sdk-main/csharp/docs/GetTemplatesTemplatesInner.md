# OneMessage.io.Model.GetTemplatesTemplatesInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Category** | **TemplateCategoryProp** |  | [optional] 
**Components** | [**TemplateComponentsProp**](TemplateComponentsProp.md) |  | [optional] 
**Language** | **TemplateLanguageProp** |  | [optional] 
**Name** | **string** |  | [optional] 
**VarNamespace** | **string** | Can be found by method /templates | [optional] 
**RejectedReason** | **string** |  | [optional] 
**Status** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

