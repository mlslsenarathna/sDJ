# OneMessage.io.Model.Ack

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | unique id of message | [optional] 
**ChatId** | **string** | chat ID | [optional] 
**Status** | **string** | type of the message status | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

