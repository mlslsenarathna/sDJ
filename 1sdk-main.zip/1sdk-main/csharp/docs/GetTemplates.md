# OneMessage.io.Model.GetTemplates

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Total** | **int** |  | [optional] 
**Templates** | [**List&lt;GetTemplatesTemplatesInner&gt;**](GetTemplatesTemplatesInner.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

