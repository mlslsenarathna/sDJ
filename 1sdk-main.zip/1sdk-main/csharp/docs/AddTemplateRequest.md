# OneMessage.io.Model.AddTemplateRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Name of template | [optional] 
**Category** | **TemplateCategoryProp** |  | [optional] 
**Components** | [**TemplateComponentsProp**](TemplateComponentsProp.md) |  | [optional] 
**Language** | **TemplateLanguageProp** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

