# OneMessage.io.Model.ChannelExtendedStatisticsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BusinessInitiatedPaidQuantity** | **int** |  | [optional] 
**BusinessInitiatedPrice** | **decimal** |  | [optional] 
**BusinessInitiatedQuantity** | **int** |  | [optional] 
**FreeEntryPoint** | **int** |  | [optional] 
**FreeQuantity** | **int** |  | [optional] 
**FreeTier** | **int** |  | [optional] 
**PaidQuantity** | **int** |  | [optional] 
**PeriodDate** | **string** |  | [optional] 
**Quantity** | **decimal** |  | [optional] 
**TotalPrice** | **decimal** |  | [optional] 
**UserInitiatedPaidQuantity** | **int** |  | [optional] 
**UserInitiatedPrice** | **decimal** |  | [optional] 
**UserInitiatedQuantity** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

