# OneMessage.io.Model.SendListRequestAllOfRows

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | Unique id for option, up to 200 symbols | 
**Title** | **string** | Title of option, up to 24 symbols. | 
**Description** | **string** | Description of option, up to 72 symbols | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

